configs = {
	'db': {
		'host': 'localhost',
		'user': 'root',
		'passwd': '131413'
	},
	'weixin': {
		'appid': 'wxcc8ccfbbb84dee40',
		'secret': '6380cb20ca709f2a615cceece81615b9'
	},
	'baidu': {
		'appid': '9662956',
		'apikey': 'dKsPksMUHqrX6GB3qBlG68Ia',
		'secret': '17ba9e02981bd9992b9a9d73feedb166'
	}
}